import classifier
import convnet as cnn
import tensorflow as tf

class Autoencoder:
  def __init__(self, n, ttype, strided=False, max_images=3):
    self.max_images = max_images
    self.n = n
    self.strided = strided
    self.ttype = ttype

  def conv(self, x, channels_shape, name):
    return cnn.conv(x, [3, 3], channels_shape, 1, name)

  def conv2(self, x, channels_shape, name):
    return cnn.conv(x, [3, 3], channels_shape, 2, name)

  def deconv(self, x, channels_shape, name):
    return cnn.deconv(x, [3, 3], channels_shape, 1, name)

  def pool(self, x):
    return cnn.max_pool(x, 2, 2)

  def unpool(self, x):
    return cnn.unpool(x, 2)

  def resize_conv(self, x, channels_shape, name):
    shape = x.get_shape().as_list()
    height = shape[1] * 2
    width = shape[2] * 2
    resized = tf.image.resize_nearest_neighbor(x, [height, width])
    return cnn.conv(resized, [3, 3], channels_shape, 1, name, repad=True)

  def dropout(self, x):
    return cnn.dropout(x, ttype=self.ttype, keep_prob=0.5)

  def inference(self, images):
    if self.strided:
      return self.strided_inference(images)
    return self.inference_with_pooling(images)

class MiniAutoencoder(Autoencoder):
  def __init__(self, n, ttype, strided=True, max_images=3):
    Autoencoder.__init__(self, n, ttype, strided=strided, max_images=max_images)

  def strided_inference(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('encode1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
      conv2 = self.conv2(conv1, [64, 64], 'conv1_2')

    with tf.variable_scope('encode2'):
      conv3 = self.conv(conv2, [64, 128], 'conv2_1')
      conv4 = self.conv2(conv3, [128, 128], 'conv2_2')

    with tf.variable_scope('encode3'):
      conv5 = self.conv(conv4, [128, 256], 'conv3_1')
      conv6 = self.conv(conv5, [256, 256], 'conv3_2')
      conv7 = self.conv2(conv6, [256, 256], 'conv3_3')

    with tf.variable_scope('decode1'):
      deconv7 = self.resize_conv(conv7, [256, 256], 'deconv3_3')
      deconv6 = self.deconv(deconv7, [256, 256], 'deconv3_2')
      deconv5 = self.deconv(deconv6, [128, 256], 'deconv3_1')

    with tf.variable_scope('decode2'):
      deconv4 = self.resize_conv(deconv5, [128, 128], 'deconv2_2')
      deconv3 = self.deconv(deconv4, [64, 128], 'deconv2_1')

    with tf.variable_scope('decode3'):
      deconv2 = self.resize_conv(deconv3, [64, 64], 'deconv1_2')
      deconv1 = self.deconv(deconv2, [self.n, 64], 'deconv1_1')

    rgb_image = classifier.rgb(deconv1)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return deconv1

class SegNetAutoencoder(Autoencoder):
  def __init__(self, n, ttype, strided=False, max_images=3):
    Autoencoder.__init__(self, n, ttype, strided=strided, max_images=max_images)

  def inference_with_pooling(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('pool1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
      conv2 = self.conv(conv1, [64, 64], 'conv1_2')
      dropout1 = self.dropout(conv2)
      pool1 = self.pool(dropout1)

    with tf.variable_scope('pool2'):
      conv3 = self.conv(pool1, [64, 128], 'conv2_1')
      conv4 = self.conv(conv3, [128, 128], 'conv2_2')
      dropout2 = self.dropout(conv4)
      pool2 = self.pool(dropout2)

    with tf.variable_scope('pool3'):
      conv5 = self.conv(pool2, [128, 256], 'conv3_1')
      conv6 = self.conv(conv5, [256, 256], 'conv3_2')
      conv7 = self.conv(conv6, [256, 256], 'conv3_3')
      dropout3 = self.dropout(conv7)
      pool3 = self.pool(dropout3)

    with tf.variable_scope('pool4'):
      conv8 = self.conv(pool3, [256, 512], 'conv4_1')
      conv9 = self.conv(conv8, [512, 512], 'conv4_2')
      conv10 = self.conv(conv9, [512, 512], 'conv4_3')
      dropout4 = self.dropout(conv10)
      pool4 = self.pool(dropout4)

    with tf.variable_scope('pool5'):
      conv11 = self.conv(pool4, [512, 512], 'conv5_1')
      conv12 = self.conv(conv11, [512, 512], 'conv5_2')
      conv13 = self.conv(conv12, [512, 512], 'conv5_3')
      dropout5 = self.dropout(conv13)
      pool5 = self.pool(dropout5)

    with tf.variable_scope('unpool1'):
      unpool1 = self.unpool(pool5)
      deconv1 = self.deconv(unpool1, [512, 512], 'deconv5_3')
      deconv2 = self.deconv(deconv1, [512, 512], 'deconv5_2')
      deconv3 = self.deconv(deconv2, [512, 512], 'deconv5_1')
      dropout6 = self.dropout(deconv3)

    with tf.variable_scope('unpool2'):
      unpool2 = self.unpool(dropout6)
      deconv4 = self.deconv(unpool2, [512, 512], 'deconv4_3')
      deconv5 = self.deconv(deconv4, [512, 512], 'deconv4_2')
      deconv6 = self.deconv(deconv5, [256, 512], 'deconv4_1')
      dropout7 = self.dropout(deconv6)

    with tf.variable_scope('unpool3'):
      unpool3 = self.unpool(dropout7)
      deconv7 = self.deconv(unpool3, [256, 256], 'deconv3_3')
      deconv8 = self.deconv(deconv7, [256, 256], 'deconv3_2')
      deconv9 = self.deconv(deconv8, [128, 256], 'deconv3_1')
      dropout8 = self.dropout(deconv9)

    with tf.variable_scope('unpool4'):
      unpool4 = self.unpool(dropout8)
      deconv10 = self.deconv(unpool4, [128, 128], 'deconv2_2')
      deconv11 = self.deconv(deconv10, [64, 128], 'deconv2_1')
      dropout9 = self.dropout(deconv11)

    with tf.variable_scope('unpool5'):
      unpool5 = self.unpool(dropout9)
      deconv12 = self.deconv(unpool5, [64, 64], 'deconv1_2')
      deconv13 = self.deconv(deconv12, [self.n, 64], 'deconv1_1')
      #dropout10 = self.dropout(deconv13)

    rgb_image = classifier.rgb(deconv13)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return deconv13

  def strided_inference(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('pool1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
      conv2 = self.conv2(conv1, [64, 64], 'conv1_2')
      dropout1 = self.dropout(conv2)

    with tf.variable_scope('pool2'):
      conv3 = self.conv(conv2, [64, 128], 'conv2_1')
      conv4 = self.conv2(conv3, [128, 128], 'conv2_2')
      dropout2 = self.dropout(conv4)

    with tf.variable_scope('pool3'):
      conv5 = self.conv(conv4, [128, 256], 'conv3_1')
      conv6 = self.conv(conv5, [256, 256], 'conv3_2')
      conv7 = self.conv2(conv6, [256, 256], 'conv3_3')
      dropout3 = self.dropout(conv7)

    with tf.variable_scope('pool4'):
      conv8 = self.conv(conv7, [256, 512], 'conv4_1')
      conv9 = self.conv(conv8, [512, 512], 'conv4_2')
      conv10 = self.conv2(conv9, [512, 512], 'conv4_3')
      dropout4 = self.dropout(conv10)

    with tf.variable_scope('pool5'):
      conv11 = self.conv(conv10, [512, 512], 'conv5_1')
      conv12 = self.conv(conv11, [512, 512], 'conv5_2')
      conv13 = self.conv2(conv12, [512, 512], 'conv5_3')
      dropout5 = self.dropout(conv13)

    with tf.variable_scope('unpool1'):
      deconv1 = self.resize_conv(conv13, [512, 512], 'deconv5_3')
      deconv2 = self.deconv(deconv1, [512, 512], 'deconv5_2')
      deconv3 = self.deconv(deconv2, [512, 512], 'deconv5_1')
      dropout6 = self.dropout(deconv3)

    with tf.variable_scope('unpool2'):
      deconv4 = self.resize_conv(deconv3, [512, 512], 'deconv4_3')
      deconv5 = self.deconv(deconv4, [512, 512], 'deconv4_2')
      deconv6 = self.deconv(deconv5, [256, 512], 'deconv4_1')
      dropout7 = self.dropout(deconv6)

    with tf.variable_scope('unpool3'):
      deconv7 = self.resize_conv(deconv6, [256, 256], 'deconv3_3')
      deconv8 = self.deconv(deconv7, [256, 256], 'deconv3_2')
      deconv9 = self.deconv(deconv8, [128, 256], 'deconv3_1')
      dropout8 = self.dropout(deconv9)

    with tf.variable_scope('unpool4'):
      deconv10 = self.resize_conv(deconv9, [128, 128], 'deconv2_2')
      deconv11 = self.deconv(deconv10, [64, 128], 'deconv2_1')
      dropout9 = self.dropout(deconv11)

    with tf.variable_scope('unpool5'):
      deconv12 = self.resize_conv(deconv11, [64, 64], 'deconv1_2')
      deconv13 = self.deconv(deconv12, [self.n, 64], 'deconv1_1')
      #dropout10 = self.dropout(deconv13)

    rgb_image = classifier.rgb(deconv13)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return deconv13


class KislayAutoencoder(Autoencoder):
  def __init__(self, n, ttype, strided=False, max_images=3):
    Autoencoder.__init__(self, n, ttype, strided=strided, max_images=max_images)

  def inference_with_pooling(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('pool1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
      conv2 = self.conv(conv1, [64, 64], 'conv1_2')
      pool1 = self.pool(conv2)

    with tf.variable_scope('pool2'):
      conv3 = self.conv(pool1, [64, 128], 'conv2_1')
      conv4 = self.conv(conv3, [128, 128], 'conv2_2')
      pool2 = self.pool(conv4)

    with tf.variable_scope('pool3'):
      conv5 = self.conv(pool2, [128, 256], 'conv3_1')
      conv6 = self.conv(conv5, [256, 256], 'conv3_2')
      conv7 = self.conv(conv6, [256, 256], 'conv3_3')
      pool3 = self.pool(conv7)

    with tf.variable_scope('unpool3'):
      unpool3 = self.unpool(pool3)
      deconv7 = self.deconv(unpool3, [256, 256], 'deconv3_3')
      deconv8 = self.deconv(deconv7, [256, 256], 'deconv3_2')
      deconv9 = self.deconv(deconv8, [128, 256], 'deconv3_1')

    with tf.variable_scope('unpool4'):
      unpool4 = self.unpool(deconv9)
      deconv10 = self.deconv(unpool4, [128, 128], 'deconv2_2')
      deconv11 = self.deconv(deconv10, [64, 128], 'deconv2_1')

    with tf.variable_scope('unpool5'):
      unpool5 = self.unpool(deconv11)
      deconv12 = self.deconv(unpool5, [64, 64], 'deconv1_2')
      deconv13 = self.deconv(deconv12, [self.n, 64], 'deconv1_1')

    rgb_image = classifier.rgb(deconv13)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return deconv13

  def strided_inference(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('pool1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
      #conv2 = self.conv2(conv1, [64, 64], 'conv1_2')
      #dropout1 = self.dropout(conv1)

    with tf.variable_scope('pool2'):
      conv3 = self.conv(conv1, [64, 128], 'conv2_1')
      #conv4 = self.conv2(conv3, [128, 128], 'conv2_2')
      #dropout2 = self.dropout(conv3)

    with tf.variable_scope('pool3'):
      conv5 = self.conv(conv3, [128, 256], 'conv3_1')
      conv6 = self.conv(conv5, [256, 256], 'conv3_2')
      #conv7 = self.conv2(conv6, [256, 256], 'conv3_3')
      #dropout3 = self.dropout(conv6)

    with tf.variable_scope('unpool3'):
      #deconv7 = self.resize_conv(conv6, [256, 256], 'deconv3_3')
      deconv8 = self.deconv(conv6, [256, 256], 'deconv3_2')
      deconv9 = self.deconv(deconv8, [128, 256], 'deconv3_1')
      #dropout8 = self.dropout(deconv9)

    with tf.variable_scope('unpool4'):
      #deconv10 = self.resize_conv(deconv9, [128, 128], 'deconv2_2')
      deconv11 = self.deconv(deconv9, [64, 128], 'deconv2_1')
      #dropout9 = self.dropout(deconv11)

    with tf.variable_scope('unpool5'):
      #deconv12 = self.resize_conv(deconv11, [64, 64], 'deconv1_2')
      deconv13 = self.deconv(deconv11, [self.n, 64], 'deconv1_1')
      #dropout10 = self.dropout(deconv13)

    rgb_image = classifier.rgb(deconv13)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return deconv13



class EncDec64_64_128_128(Autoencoder):
  def __init__(self, n, ttype, strided=True, max_images=3):
    Autoencoder.__init__(self, n, ttype, strided=strided, max_images=max_images)

  def inference_with_pooling(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('pool1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
      conv2 = self.conv(conv1, [64, 64], 'conv1_2')
      pool1 = self.pool(conv2)

    with tf.variable_scope('pool2'):
      conv3 = self.conv(pool1, [64, 128], 'conv2_1')
      conv4 = self.conv(conv3, [128, 128], 'conv2_2')
      pool2 = self.pool(conv4)

    with tf.variable_scope('unpool4'):
      unpool4 = self.unpool(pool2)
      deconv1 = self.deconv(unpool4, [128, 128], 'deconv2_2')
      deconv2 = self.deconv(deconv1, [64, 128], 'deconv2_1')

    with tf.variable_scope('unpool5'):
      unpool5 = self.unpool(deconv2)
      deconv3 = self.deconv(unpool5, [64, 64], 'deconv1_2')
      deconv4 = self.deconv(deconv3, [self.n, 64], 'deconv1_1')

    rgb_image = classifier.rgb(deconv4)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return deconv4

  def strided_inference(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('conv_group_1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
    
    with tf.variable_scope('conv_group_2'):
      conv2 = self.conv(conv1, [64, 128], 'conv2_1')

    with tf.variable_scope('conv_group_3'):
      conv3 = self.conv(conv2, [128, 256], 'conv3_1')
      conv4 = self.conv(conv3, [256, 256], 'conv3_2')
    
    with tf.variable_scope('conv_group_4'):
      conv5 = self.conv(conv4, [256, 512], 'conv4_1')
      conv6 = self.conv(conv5, [512, 512], 'conv4_2')
      conv7 = self.conv(conv6, [512, self.n], 'conv4_3')
      

    rgb_image = classifier.rgb(conv7)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return conv7


class EncDec64_64(Autoencoder):
  def __init__(self, n, ttype, strided=True, max_images=3):
    Autoencoder.__init__(self, n, ttype, strided=strided, max_images=max_images)

  def inference_with_pooling(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('pool1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
      pool1 = self.pool(conv1)

    with tf.variable_scope('unpool5'):
      unpool5 = self.unpool(pool1)
      deconv3 = self.deconv(unpool5, [64, 64], 'deconv1_2')
      deconv4 = self.deconv(deconv3, [self.n, 64], 'deconv1_1')

    rgb_image = classifier.rgb(deconv4)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return deconv4

  def strided_inference(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('conv_group_1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
    
    with tf.variable_scope('conv_group_2'):
      conv2 = self.conv(conv1, [64, 128], 'conv2_1')

    with tf.variable_scope('conv_group_3'):
      conv3 = self.conv(conv2, [128, 256], 'conv3_1')
      conv4 = self.conv(conv3, [256, 256], 'conv3_2')
    
    with tf.variable_scope('conv_group_4'):
      conv5 = self.conv(conv4, [256, 512], 'conv4_1')
      conv6 = self.conv(conv5, [512, 512], 'conv4_2')
      conv7 = self.conv(conv6, [512, self.n], 'conv4_3')
      

    rgb_image = classifier.rgb(conv7)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return conv7

class Conv3layers(Autoencoder):
  def __init__(self, n, ttype, strided=True, max_images=3):
    Autoencoder.__init__(self, n, ttype, strided=strided, max_images=max_images)

  def inference_with_pooling(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('encode1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
      conv2 = self.conv(conv1, [64, 128], 'conv1_2')
      conv3 = self.conv(conv2, [128, 256], 'conv1_3')
      conv4 = self.conv(conv3, [256, self.n], 'conv1_4')

    rgb_image = classifier.rgb(conv4)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return conv4

  def strided_inference(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('conv_group_1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
    
    with tf.variable_scope('conv_group_2'):
      conv2 = self.conv(conv1, [64, 128], 'conv2_1')

    with tf.variable_scope('conv_group_3'):
      conv3 = self.conv(conv2, [128, 256], 'conv3_1')
      conv4 = self.conv(conv3, [256, 256], 'conv3_2')
    
    with tf.variable_scope('conv_group_4'):
      conv5 = self.conv(conv4, [256, 512], 'conv4_1')
      conv6 = self.conv(conv5, [512, 512], 'conv4_2')
      conv7 = self.conv(conv6, [512, self.n], 'conv4_3')
      

    rgb_image = classifier.rgb(conv7)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return conv7

class ConvVGG(Autoencoder):
  def __init__(self, n, ttype, strided=True, max_images=3):
    Autoencoder.__init__(self, n, ttype, strided=strided, max_images=max_images)

  def inference_with_pooling(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('conv_group_1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')

    with tf.variable_scope('conv_group_2'):
      conv2 = self.conv(conv1, [64, 128], 'conv2_1')

    with tf.variable_scope('conv_group_3'):
      conv3 = self.conv(conv2, [128,256], 'conv3_1')
      conv4 = self.conv(conv3, [256,256], 'conv3_2')

    with tf.variable_scope('conv_group_4'):
      conv5 = self.conv(conv4, [256,512], 'conv4_1')
      conv6 = self.conv(conv5, [512,512], 'conv4_2')
      conv7 = self.conv(conv6, [512,self.n], 'conv4_3')

    rgb_image = classifier.rgb(conv7)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return conv7

  def strided_inference(self, images):
    tf.summary.image('input', images, max_outputs=self.max_images)

    with tf.variable_scope('conv_group_1'):
      conv1 = self.conv(images, [3, 64], 'conv1_1')
      #conv2 = self.conv(conv1, [64, 64], 'conv1_2')
    
    with tf.variable_scope('conv_group_2'):
      conv2 = self.conv(conv1, [64, 128], 'conv2_1')

    with tf.variable_scope('conv_group_3'):
      conv3 = self.conv(conv2, [128, 256], 'conv3_1')
      conv4 = self.conv(conv3, [256, 256], 'conv3_2')
    
    with tf.variable_scope('conv_group_4'):
      conv5 = self.conv(conv4, [256, 512], 'conv4_1')
      conv6 = self.conv(conv5, [512, 512], 'conv4_2')
      conv7 = self.conv(conv6, [512, self.n], 'conv4_3')
      

    rgb_image = classifier.rgb(conv7)
    tf.summary.image('output', rgb_image, max_outputs=self.max_images)
    return conv7