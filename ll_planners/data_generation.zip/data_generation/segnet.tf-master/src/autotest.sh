#!/bin/sh
# make sure /data/ is *ONLY* filled with test env folders you wish to test, with 1 datum and 1 label per env

# make results folder if it doesn't exist
if [ ! -d results ]; then
	mkdir results
fi

# remove existing results and tfrecords
rm results/*
rm input/waypoint-2d/*

# loop through test envs and get results
for testenv in ../../datatest/*/; do
	# move test data into segnet folder
	cp "$testenv"img/* input/raw/test/
	cp "$testenv"gaze/* input/raw/test-labels/

	# obtain tfrecrods for test env
	python tfrecorder.py

	# run test script
	ENVNUM=${testenv#*v}
	ENVNUM=${ENVNUM%/*}
	python test.py "$ENVNUM"

	# overlay results with env to get better view of results
	python ../../resultdisplay2.py input/raw/test/"$ENVNUM"0.png results/"env$ENVNUM"_output.png results/m"$ENVNUM".png

	# clear folders for next run
	rm input/waypoint-2d/*
	rm input/raw/test/*
	rm input/raw/test-labels/*
done


