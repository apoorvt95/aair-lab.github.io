autoencoder = 'kislay'

working_dataset = 'waypoint-2d'

colors = {
	'waypoint-2d': 
	[
	    [255, 255, 255],     # path
	    [0, 0, 0]       # void
	]}

gpu_memory_fraction = 0.7

strided = False
