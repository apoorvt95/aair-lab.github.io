import pdb
import time
from sys import *
from trainingdata import mNavigationPlanningLabels
from openravepy import *
from numpy import *


if len(argv) == 3:
	envPath = argv[1]
	envnum = float(argv[2])
else:
	print '\nincorrect number of arguments passed'
	exit(0)

try:
	env = Environment()
	env.Load(envPath)
	
	env.SetViewer('qtcoin')
	viewer = env.GetViewer()
	#viewer.SetSize(900,900)
	viewer.SetCamera([[  9.99989147e-01,  -3.08830989e-03,   3.48815543e-03,
	          3.30109894e-02],
	       [ -3.08664267e-03,  -9.99995120e-01,  -4.83250519e-04,
	          5.10825627e-02],
	       [  3.48963084e-03,   4.72478585e-04,  -9.99993800e-01,
	          6.83978987e+00],
	       [  0.00000000e+00,   0.00000000e+00,   0.00000000e+00,
	          1.00000000e+00]])

	if envnum == 9.1 or envnum == 11.0:
		viewer.SetCamera([[ 9.99989147e-01, -3.08832100e-03,  3.48816944e-03,
        -3.59330550e-02],
       [-3.08665437e-03, -9.99995120e-01, -4.83077509e-04,
         6.06323667e-02],
       [ 3.48964431e-03,  4.72305493e-04, -9.99993800e-01,
         2.66048508e+01],
       [ 0.00000000e+00,  0.00000000e+00,  0.00000000e+00,
         1.00000000e+00]])
	
	elif envnum == 10.2:
		viewer.SetCamera([[ 9.99989147e-01, -3.08832100e-03,  3.48816944e-03,
         1.86725594e-02],
       [-3.08665437e-03, -9.99995120e-01, -4.83077509e-04,
         5.30681610e-02],
       [ 3.48964431e-03,  4.72305493e-04, -9.99993800e-01,
         1.09503689e+01],
       [ 0.00000000e+00,  0.00000000e+00,  0.00000000e+00,
         1.00000000e+00]])
	
	# set collision checker to Bullet (default collision checker might not recognize cylinder collision for Ubuntu) (causes issues when moving joints)
	collisionChecker = RaveCreateCollisionChecker(env, 'fcl_') #fcl_,pqp,bullet
	#collisionChecker.SetCollisionOptions(CollisionOptions.Distance|CollisionOptions.Contacts) # doesnt work with fcl
	env.SetCollisionChecker(collisionChecker)
	#pdb.set_trace()
	# load robots
	robot = env.GetRobots()[0]
	env.UpdatePublishedBodies()
	time.sleep(0.1)
	'''
	# obtain boundaries of the environment
	with env:
		envmin = []
		envmax = []

		for b in env.GetBodies():
			ab = b.ComputeAABB()
			envmin.append(ab.pos()-ab.extents())
			envmax.append(ab.pos()+ab.extents())

		abrobot = robot.ComputeAABB()
		envmin = numpy.min(numpy.array(envmin),0)+abrobot.extents()
		envmax = numpy.max(numpy.array(envmax),0)-abrobot.extents()

	bounds = numpy.array(((envmin[0],envmin[1],-pi),(envmax[0],envmax[1],pi)))
	'''
	bounds = array([[-2.5, -2.5, -3.14], [2.5, 2.5, 3.14]]) 
	envmin = array([-2.5, -2.5, -2.5])
	envmax = array([2.5, 2.5, 2.5])
	if envnum == 9.1 or envnum == 11.0:
  		bounds = array([[-10, -10, -3.14], [10, 10, 3.14]])
  		envmin = array([-10, -10, -10])
		envmax = array([10, 10, 10])
	elif envnum == 9.2:
		robot.Grab(env.GetKinBody('mug6'))
	elif envnum == 10.2:
		robot.Grab(env.GetKinBody('mug6'))
		bounds = array([[-4, -4, -3.14], [4, 4, 3.14]])
  		envmin = array([-4, -4, -4])
		envmax = array([4, 4, 4])

	# perform motion planning
	planner = mNavigationPlanningLabels(robot, envnum, bounds, [envmin, envmax])
	starttime = time.time()
	planner.performNavigationPlanning()
	print '\n\ntiming: '+str(time.time()-starttime)
	
finally:
	# destory environment
	RaveDestroy()

