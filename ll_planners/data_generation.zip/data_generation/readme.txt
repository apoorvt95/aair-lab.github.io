To generate training data:

make sure folder "data/env"env_num"/" exists and is populated with then following folders: "img", "lbl", "gaze", "sm"

python simulation "env_path" "env_num"

	env_path: env/0.0.xml
	env_num: 0.0