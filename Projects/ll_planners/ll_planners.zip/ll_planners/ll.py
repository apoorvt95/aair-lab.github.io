from __future__ import division
from openravepy import *
from functools import partial
from scipy.spatial import distance
from sklearn.neighbors import KDTree
from sys import *
from numpy import * 
import time
import os
from heapq import *
import pdb 

RaveSetDebugLevel(0)

envnum = argv[1]
NUMRUNS = int(argv[2])
MAXTIME = float(argv[3])
mode = argv[3].lower()

numpy.random.seed(None) #random seed

def load_samples():
	with open(os.path.join('samples', 'samples_env' + envnum +  '.pkl'), 'rb') as samplefile:
		samples = pickle.load(samplefile)
	return samples

class LL(object):
	def __init__(self,env,jointlimits,samples,n,m,s=[],g=[]):
		super(LL, self).__init__()
		self.starttime = time.time()
		self.trace = []
		self.samplecount = 0
		self.n = n
		self.m = m
		self.env = env
		self.samples = samples
		self.jointlimits = jointlimits
		if envnum == '9.2' or envnum == '10.2':
			self.goalradius = 0.5
		else:
			self.goalradius = 0.25
		
		self.currentgraph = 0
		self.currentstate = 'build graphs'
		self.s = s
		self.g = g
		self.color = (0,1,0)
		self.traceheight = 0.25
		self.build_roadmap()

	def collides(self,q):
		collision = False
		robot = self.env.GetRobots()[0]	

		with self.env:
			prev = robot.GetActiveDOFValues()
			robot.SetActiveDOFValues(q)
			if self.env.CheckCollision(robot):
				collision = True
			robot.SetActiveDOFValues(prev)

		return collision

	def sample_uniform(self):		
		self.samplecount += 1
		state = [0.0 for i in xrange(len(self.jointlimits[0]))]
		for i, jlowlimit in enumerate(self.jointlimits[0]):
			state[i] = random.uniform(jlowlimit, self.jointlimits[1][i])

		return state

	def sample_samples(self):
		rand = self.sample_uniform()
		randsample = random.choice(len(self.samples), size=1, replace=False)
		pointx = (self.samples[randsample[0]][0]+self.samples[randsample[0]][2])/2.0
		pointy = (self.samples[randsample[0]][1]+self.samples[randsample[0]][3])/2.0
		state = rand[0:len(rand)-3]+[pointx,pointy]+[rand[len(rand)-1]]

		return state

	def dist(self,p1,p2):
		a = numpy.array(p1)
		b = numpy.array(p2)

		return numpy.linalg.norm(a-b)

	def compound_step(self,p1,p2):
		if len(p1) == 10:
			a = self.step_from_to(p1[0:7],p2[0:7],0.5)
			b = self.step_from_to(p1[7:9],p2[7:9],0.5) #0.2
			c = self.step_from_to([p1[9]],[p2[9]],0.5) #0.2
			return a+b+c
		else:
			a = self.step_from_to(p1[len(p1)-3:len(p1)-1],p2[len(p2)-3:len(p2)-1],0.2)
			b = self.step_from_to([p1[len(p1)-1]],[p2[len(p2)-1]],0.2)
			return a+b

	def step_from_to(self,p1,p2,distance):
		#https://github.com/motion-planning/rrt-algorithms/blob/master/src/rrt/rrt_base.py
		if self.dist(p1,p2) <= distance:
			return p2
		else:
			a = numpy.array(p1)
			b = numpy.array(p2)
			ab = b-a  # difference between start and goal

			zero_vector = numpy.zeros(len(ab))

			ba_length = self.dist(zero_vector, ab)  # get length of vector ab
			unit_vector = numpy.fromiter((i / ba_length for i in ab), numpy.float, len(ab))
			# scale vector to desired length
			scaled_vector = numpy.fromiter((i * distance for i in unit_vector), numpy.float, len(unit_vector))
			steered_point = numpy.add(a, scaled_vector)  # add scaled vector to starting location for final point

			return list(steered_point)

	def goal_zone_collision(self,p1,p2):
		if self.dist(p1, p2) <= self.goalradius:
			return True
		else:
			return False

	def local_planner(self,s,g):
		''' straight line planning '''
		result = False
		prev = s
		while True:
			step = self.compound_step(prev,g)
			if self.collides(step):
				break
			elif self.goal_zone_collision(step,g):
				result = True
				break
			else:
				prev = step 
		
		return result

	def connect(self, V, E, q):
		status = 'advanced'

		# loop until reached or collision
		while status is 'advanced':
			V, E, status, new = self.extend(V, E, q)

		if status == 'reached':
			# add G=(V,E) to q's graph
			i_q = len(self.roadmap[self.currentgraph])-1 
			self.roadmap[self.currentgraph] = self.roadmap[self.currentgraph] + V
			for i, e in enumerate(E):
				adj = []
				for n in E[e]:
					adj.append((n[0]+i_q+1,n[1]))
				self.roadmapedges[self.currentgraph][i_q+1+i] = adj

			i_new = len(self.roadmap[self.currentgraph])-1
			self.roadmapedges[self.currentgraph][i_q].append((i_new,new))
			self.roadmapedges[self.currentgraph][i_new].append((i_q,q))
			self.trace.append(self.env.drawlinestrip(points=array([[q[len(q)-3], q[len(q)-2], self.traceheight],[new[len(new)-3], new[len(new)-2], self.traceheight]]), linewidth=0.5, colors=array(self.color), drawstyle=1))		

		return status 
		
	def extend(self, V, E, q):
		i_near = distance.cdist([q], V).argmin()
		near = V[i_near]
		new = self.compound_step(near, q)

		if self.collides(new) == False:  
			V.append(new)
			E[len(V)-1] = []
			E[len(V)-1].append((i_near,near)) 
			E[i_near].append((len(V)-1,new))
			self.trace.append(self.env.plot3(points=[new[len(new)-3], new[len(new)-2], self.traceheight], pointsize=0.03, colors=array(self.color), drawstyle=1))
			self.trace.append(self.env.drawlinestrip(points=array([[near[len(near)-3], near[len(near)-2], self.traceheight],[new[len(new)-3], new[len(new)-2], 0.25]]), linewidth=0.5, colors=array(self.color), drawstyle=1))
			
			if self.goal_zone_collision(new, q):
				return V, E, 'reached', new
			else:
				return V, E, 'advanced', new
		else:
			return V, E, 'trapped', None 

	def connectN(self, q):
		delete = []
		for i in xrange(len(self.roadmap)):
			if i != self.currentgraph:
				connected = self.connect(self.roadmap[i], self.roadmapedges[i], q)
				if connected is 'reached': 
					delete.append(i)

		# delete merged graphs
		self.roadmap = [self.roadmap[i] for i in xrange(len(self.roadmap)) if not i in delete]
		self.roadmapedges = [self.roadmapedges[i] for i in xrange(len(self.roadmapedges)) if not i in delete]

		return len(self.roadmap) == 1

	def connect_2(self, V, E, q):
		status = 'advanced'

		# loop until reached or collision
		while status is 'advanced':
			V, E, status, new = self.extend(V, E, q)

		if status == 'reached':
			i_new = len(V)-1 
			V = V + self.roadmap[self.currentgraph]
			for i, e in enumerate(self.roadmapedges[self.currentgraph]):
				adj = []
				for n in self.roadmapedges[self.currentgraph][e]:
					adj.append((n[0]+i_new-1,n[1]))
				E[i_new+1+i] = adj

			i_q = len(V)-1
			E[i_q].append((i_new,new))
			E[i_new].append((i_q,q))
			self.trace.append(self.env.drawlinestrip(points=array([[q[len(q)-3], q[len(q)-2], self.traceheight],[new[len(new)-3], new[len(new)-2], self.traceheight]]), linewidth=0.5, colors=array(self.color), drawstyle=1))		

		return V, E, status 

	def connectN_2(self, q):
		merged = False

		if self.currentgraph == 0: 
			self.roadmap[1], self.roadmapedges[1], connected = self.connect_2(self.roadmap[1], self.roadmapedges[1], q)
			if connected is 'reached': 
				del self.roadmap[self.currentgraph]
				del self.roadmapedges[self.currentgraph]
				merged = True
				return True, merged
			else:
				return False, merged
		elif self.currentgraph == 1: 
			self.roadmap[0], self.roadmapedges[0], connected = self.connect_2(self.roadmap[0], self.roadmapedges[0], q)
			if connected is 'reached':
				del self.roadmap[self.currentgraph]
				del self.roadmapedges[self.currentgraph]
				merged = True
				return True, merged
			else:
				return False, merged
		else: 
			self.roadmap[0], self.roadmapedges[0], connected = self.connect_2(self.roadmap[0], self.roadmapedges[0], q)
			if connected is 'reached':
				del self.roadmap[self.currentgraph]
				del self.roadmapedges[self.currentgraph]
				merged = True
			else:
				self.roadmap[1], self.roadmapedges[1], connected = self.connect_2(self.roadmap[1], self.roadmapedges[1], q)
				if connected is 'reached':
					del self.roadmap[self.currentgraph]
					del self.roadmapedges[self.currentgraph]
					merged = True
			return False, merged

	def swapN(self):
		if self.currentgraph >= len(self.roadmap)-1:
			self.currentgraph = 0
		else:
			self.currentgraph += 1

	def swapN_2(self, merged):
		if not merged:
			if self.currentgraph == len(self.roadmap)-1:
				self.currentgraph = 0
			else:
				self.currentgraph += 1
		else:
			# since merged trees, cluster number will already be set for new round; only change if merged tree at end of list
			if self.currentgraph >= len(self.roadmap):
				self.currentgraph = 0

	def build_roadmap(self):
		global mode

		self.roadmap = []
		self.roadmapedges = []

		while len(self.roadmap) < self.n:
			while True:
				q = self.sample_samples()
				if not self.collides(q):
					break
			self.roadmap.append([q])
			self.roadmapedges.append({0:[]})
			self.trace.append(self.env.plot3(points=[q[len(q)-3], q[len(q)-2], 0.25], pointsize=0.03, colors=array((1,0,0)), drawstyle=1))

		while (len(self.roadmap)-self.n) < self.m:
			while True:
				q = self.sample_uniform()
				if not self.collides(q):
					break
			self.roadmap.append([q])
			self.roadmapedges.append({0:[]})
			self.trace.append(self.env.plot3(points=[q[len(q)-3], q[len(q)-2], 0.25], pointsize=0.03, colors=array((0,0,1)), drawstyle=1))
		
		if len(self.s) > 0 and len(self.g) > 0:
			self.roadmap.append([self.s])
			self.roadmapedges.append({0:[]})
			self.roadmap.append([self.g])
			self.roadmapedges.append({0:[]})

		if mode == 'llp':
			buildtime = 60
		else:
			buildtime = 1

		while True:
			if (time.time()-self.starttime) <= buildtime: # 1 seconds to build in RM mode. 60 in llp
				rand = self.sample_uniform()
				self.roadmap[self.currentgraph], self.roadmapedges[self.currentgraph], status, new = self.extend(self.roadmap[self.currentgraph], self.roadmapedges[self.currentgraph], rand)

				if status != 'trapped':
					connected = self.connectN(new)

					if connected:
						print str(time.time()-self.starttime) + ',' + str(len(self.roadmap[0])) # comment put for llp
						self.currentstate = 'connected graphs'
						break

				if self.currentstate == 'build graphs':
					self.swapN()
			else:
				if mode == 'll-rm':		
					# comment out below in llp mode
					self.currentstate = 'connected graphs'
					numstates = 0
					for m in self.roadmap:
						numstates += len(m)
					print str(time.time()-self.starttime) + ',' + str(numstates)
				
					break

	def build_roadmap_prm(self):
		self.edges = {}
		self.vertices = []
		self.k = 3

		while len(self.vertices) < self.n:
			while True:
				q = self.sample_samples()
				if not self.collides(q):
					break
			self.vertices.append(q)
			self.trace.append(self.env.plot3(points=[q[len(q)-3], q[len(q)-2], 0.25], pointsize=0.03, colors=array((1,0,0)), drawstyle=1))

		while (len(self.vertices)-self.n) < self.m:
			while True:
				q = self.sample_uniform()
				if not self.collides(q):
					break
			self.vertices.append(q)
			self.trace.append(self.env.plot3(points=[q[len(q)-3], q[len(q)-2], 0.25], pointsize=0.03, colors=array((0,0,1)), drawstyle=1))

		self.kdtree = KDTree(self.vertices)
		 
		for i_v, q in enumerate(self.vertices):
			dist, ind = self.kdtree.query([q],k=self.k+1)
			self.edges[i_v] = []
			for i_n in ind[0]:
				if i_n != i_v:
					n = self.vertices[i_n]
					if (not (i_n,n) in self.edges[i_v]) and self.local_planner(q,n):
						self.edges[i_v].append((i_n,n))
						self.trace.append(self.env.drawlinestrip(points=array([[q[len(q)-3], q[len(q)-2], 0.25],[n[len(n)-3], n[len(n)-2], 0.25]]), linewidth=0.5, colors=array((0,1,0)), drawstyle=1))

		return True

	def search(self):
		''' dijkstra's '''
		q = []
		dist = {}
		prev = {}
		
		for i in xrange(len(self.roadmap[0])):
			dist[i] = inf
			prev[i] = None

		dist[self.start[0]] = 0
		heappush(q, (0,self.start))

		while q:
			currdist, near = heappop(q)

			for n in self.roadmapedges[0][near[0]]:
				alt = currdist + self.dist(near[1], n[1])
				if alt < dist[n[0]]:
					dist[n[0]] = alt
					prev[n[0]] = near
					heappush(q, (alt, n))

		# collect solution path through backtracking from goal using prev
		solutiontrace = []
		temp = self.goal
		if prev[temp[0]]:
			while temp:
				solutiontrace.append(temp[1])
				temp = prev[temp[0]]

		return solutiontrace

	def refine(self,path):
		solution = []
		pdb.set_trace()
		for i in [0, len(path)-2]:
			section = []
			prev = path[i]
			section.append(prev)
			self.trace.append(self.env.plot3(points=[prev[len(prev)-3], prev[len(prev)-2], 0.25], pointsize=0.03, colors=array((0,1,0)), drawstyle=1))
			while not self.goal_zone_collision(step, path[i+1]):
				step = self.compound_step(prev,path[i+1])
				section.append(step)
				self.trace.append(self.env.plot3(points=[step[len(step)-3], step[len(step)-2], 0.25], pointsize=0.03, colors=array((0,1,0)), drawstyle=1))
				self.trace.append(self.env.drawlinestrip(points=array([[prev[len(prev)-3], prev[len(prev)-2], 0.25],[step[i+1][len(step[i+1])-3], step[i+1][len(step[i+1])-2], 0.25]]), linewidth=0.5, colors=array((0,1,0)), drawstyle=1))
				prev = step
			solution.append(section)
		#pdb.set_trace()
		return solution

	def visualize(self, solutiontrace):
		robot = self.env.GetRobots()[0]
		tracerobots = []
		
		for point in solutiontrace:
			robot.SetActiveDOFValues(point)
			time.sleep(0.1)
		
		'''
		time.sleep(0.1)
		for point in solutiontrace:
			robot.SetActiveDOFValues(point)
			newrobot = RaveCreateRobot(self.env,robot.GetXMLId())
			newrobot.Clone(robot,0)
			#for link in newrobot.GetLinks():
			#	for geom in link.GetGeometries():
			#		geom.SetTransparency(0.5)	
			newrobot.SetTransform(robot.GetTransform())
			self.env.Add(newrobot,True)
			tracerobots.append(newrobot)
			time.sleep(0.025)		

		self.env.UpdatePublishedBodies()
		pdb.set_trace()
		for bot in tracerobots:
			self.env.Remove(bot)
			time.sleep(0.01)
		del tracerobots
		'''
		#pdb.set_trace()

	def plan(self,s,g,visualize=False):
		global mode

		if mode == 'll-rm':
			self.starttime = time.time() # comment out for llp

		if len(self.s) == 0 and len(self.g) == 0:
			self.currentgraph = 0
			self.currentstate = 'build graphs'
			self.color = (1,0,1)
			self.traceheight = 0.3
			self.roadmap.append([s])
			self.roadmapedges.append({0:[]})
			self.roadmap.append([g])
			self.roadmapedges.append({0:[]})
			
			while (time.time()-self.starttime) <= MAXTIME:
				rand = self.sample_uniform()
				self.roadmap[self.currentgraph], self.roadmapedges[self.currentgraph], status, new = self.extend(self.roadmap[self.currentgraph], self.roadmapedges[self.currentgraph], rand)

				if status != 'trapped':
					connected = self.connectN(new)

					if connected:
						self.currentstate = 'connected graphs' 
						break

				if self.currentstate == 'build graphs':
					self.swapN()

		if self.currentstate == 'connected graphs':
			i_s = distance.cdist([s], self.roadmap[0]).argmin()
			i_g = distance.cdist([g], self.roadmap[0]).argmin()
			self.start = (i_s,s)
			self.goal = (i_g,g)

			path = self.search()
			if len(path) > 0:
				print str(time.time()-self.starttime) + ',' + str(len(self.roadmap[0]))
				if visualize:
					path = path[::-1]
					for point in path:
						self.trace.append(self.env.plot3(points=[point[len(point)-3], point[len(point)-2], 0.3], pointsize=0.05, colors=array((0,1,1)), drawstyle=1))
					time.sleep(0.1)
					pdb.set_trace()
					self.visualize(path)
				#pdb.set_trace()
				return True
			else:
				#pdb.set_trace()
				return False
		else:
			numstates = 0
			for m in self.roadmap:
				numstates += len(m)
			print 'out of time' + ',' + str(time.time()-self.starttime) + ',' + str(numstates)
			#pdb.set_trace()
			return False

def main():
	try:
		env = Environment()
		env.Load('envs/'+envnum+'.xml')
		
		env.SetViewer('qtcoin')
		viewer = env.GetViewer()
		viewer.SetSize(500,500)
		if envnum == '9.1' or envnum == '11.0':
			viewer.SetCamera([[ 9.99989147e-01, -3.08832100e-03,  3.48816944e-03,
	        -3.59330550e-02],
	       [-3.08665437e-03, -9.99995120e-01, -4.83077509e-04,
	         6.06323667e-02],
	       [ 3.48964431e-03,  4.72305493e-04, -9.99993800e-01,
	         2.66048508e+01],
	       [ 0.00000000e+00,  0.00000000e+00,  0.00000000e+00,
	         1.00000000e+00]])
		elif envnum == '10.2':
			viewer.SetCamera([[ 9.99989147e-01, -3.08832100e-03,  3.48816944e-03,
		     1.86725594e-02],
		   [-3.08665437e-03, -9.99995120e-01, -4.83077509e-04,
		     5.30681610e-02],
		   [ 3.48964431e-03,  4.72305493e-04, -9.99993800e-01,
		     1.09503689e+01],
		   [ 0.00000000e+00,  0.00000000e+00,  0.00000000e+00,
		     1.00000000e+00]])
		else:
			viewer.SetCamera([[  9.99989147e-01,  -3.08830989e-03,   3.48815543e-03,
	          3.30109894e-02],
	       [ -3.08664267e-03,  -9.99995120e-01,  -4.83250519e-04,
	          5.10825627e-02],
	       [  3.48963084e-03,   4.72478585e-04,  -9.99993800e-01,
	          6.83978987e+00],
	       [  0.00000000e+00,   0.00000000e+00,   0.00000000e+00,
	          1.00000000e+00]])
		
		
		collisionChecker = RaveCreateCollisionChecker(env, 'fcl_')
		env.SetCollisionChecker(collisionChecker)
		
		# load robots
		robot = env.GetRobots()[0]
		try:
			robot.SetActiveDOFs(robot.GetActiveManipulator().GetArmIndices(),DOFAffine.X|DOFAffine.Y|DOFAffine.RotationAxis,[0,0,1]) # set arm joints
			robot.Grab(env.GetKinBody('mug6'))
		except:
			robot.SetActiveDOFs([],DOFAffine.X|DOFAffine.Y|DOFAffine.RotationAxis,[0,0,1]) # set arm joints
		jointlimits = list(robot.GetActiveDOFLimits())
		env.UpdatePublishedBodies()
		time.sleep(0.1)
	 
		with env:
			loc = [0.0 for i in xrange(len(jointlimits[0])-3)]+[15, 15, 0.0]
			robot.SetActiveDOFValues(loc)

		if envnum == '9.0':
		    start = [0.0 for i in xrange(len(jointlimits[0])-3)]+[1.5,-1.5,0.0]
		    goal = [0.0 for i in xrange(len(jointlimits[0])-3)]+[-1.5,-1.0,0.0]
		    bounds = array([[-2.5, -2.5, -pi], [2.5, 2.5, pi]])
		elif envnum == '9.1':
		    start = [0.0 for i in xrange(len(jointlimits[0])-3)]+[-7,-7,0.0] 
		    goal = [0.0 for i in xrange(len(jointlimits[0])-3)]+[-9,7,0.0]
		    bounds = array([[-10, -10, -pi], [10, 10, -pi]])
		elif envnum == '9.2':
		    start = [0.0205585116,0.593383701,-0.114082917,2.03588441,0,0.518159381,3]+[-0.8,0.14,0]
		    goal = [0.0205585116,0.593383701,-0.114082917,2.03588441,0,0.518159381,3]+[-1.76,-1.73,0]
		    bounds = array([[-2.5, -2.5, -pi], [2.5, 2.5, pi]])
		elif envnum == '10.2':
		    start = [0.0205585116,0.593383701,-0.114082917,2.03588441,0,0.518159381,3]+[-1.19361,-1.65621,0]
		    goal = [0.0205585116,0.593383701,-0.114082917,2.03588441,0,0.518159381,3]+[1.59429526,-0.857801855,-1.56981169]
		    bounds = array([[-4, -4, -pi], [4, 4, pi]])
		elif envnum == '11.0':
			start = [0.0 for i in xrange(len(jointlimits[0])-3)]+[2.5,-9.25,0]
			goal = [0.0 for i in xrange(len(jointlimits[0])-3)]+[1.25,9.5,0]
			bounds = array([[-10, -10, -pi], [10, 10, -pi]])
		else:
		    start = [0.0 for i in xrange(len(jointlimits[0])-3)]+[1.5,-1.5,0]
		    goal = [0.0 for i in xrange(len(jointlimits[0])-3)]+[-1.5,-1.5,0]
		    bounds = array([[-2.5, -2.5, -pi], [2.5, 2.5, pi]])
		
		jointlimits[0] = list(jointlimits[0][0:len(jointlimits[0])-3]) + list(bounds[0])
		jointlimits[1] = list(jointlimits[1][0:len(jointlimits[1])-3]) + list(bounds[1])
		samples = load_samples()

		if mode == 'llp':
			n = int(0.05*len(samples))
			m = 0

			for i in xrange(NUMRUNS):
				problem = LL(env,jointlimits,samples,n,m,start,goal)
				success = problem.plan(start,goal)
		else:
			n = int(0.05*len(samples))
			m = int(n/10)

			for i in xrange(NUMRUNS):
				problem = LL(env,jointlimits,samples,n,m)
				success = problem.plan(start,goal)			

	finally:
		RaveDestroy()

if __name__ == "__main__":
    main()



