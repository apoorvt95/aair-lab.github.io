To run and save OMPL planners:

python ompl.py "envum" "num_runs" "planner" >> logs/ompl/"planner"/logs_env"envnum".txt

	planner: rrt, birrt, prm
	envnum: 8.0,9.2,10.0,10.2
	num_runs: 1,2,3,...


To run the LL planners:

python ll.py "envum" "num_runs" 60 "mode" >> logs/ll/"mode"/logs_env"envnum".txt

	envnum: 8.0,9.2,10.0,10.2
	num_runs: 1,2,3,...
	mode: LLP, LL-RM


To plot results:

python plots.py "envum" 60 "LLP LL-RM"

	envnum: 8.0,9.2,10.0,10.2