from __future__ import division
import pdb, os
from sys import argv
import pandas as pd
import numpy as np
import seaborn as stime
import matplotlib.pyplot as plt

def setAxLinesBW(ax):
    """
    Take each Line2D in the axes, ax, and convert the line style to be 
    suitable for black and white viewing.
    """
    MARKERSIZE = 5

    COLORMAP = {
        'b': {'marker': None, 'dash': (None,None)},
        'g': {'marker': None, 'dash': [5,5]},
        'r': {'marker': None, 'dash': [5,3,1,3]},
        'c': {'marker': None, 'dash': [1,3]},
        'm': {'marker': None, 'dash': [5,2,5,2,5,10]},
        'y': {'marker': None, 'dash': [5,3,1,2,1,10]},
        'k': {'marker': 'o', 'dash': (None,None)} #[1,2,1,10]}
        }


    lines_to_adjust = ax.get_lines()
    try:
        lines_to_adjust += ax.get_legend().get_lines()
    except AttributeError:
        pass
    
    for line in lines_to_adjust:
        origColor = line.get_color()
        
        if origColor == (0.8666666666666667, 0.5176470588235295, 0.3215686274509804):
        	line.set_color('black')
        	line.set_dashes([1,2,1,5])
      	elif origColor == (0.2980392156862745, 0.4470588235294118, 0.6901960784313725):
      		line.set_color('black')
      		line.set_dashes([5,5])
        elif origColor == (0.3333333333333333, 0.6588235294117647, 0.40784313725490196):
        	line.set_color('black')
      		line.set_dashes([5,3,1,3])
      	elif origColor == (0.7686274509803922, 0.3058823529411765, 0.3215686274509804):
      		line.set_color('black')
      		line.set_dashes([1,3])
      	elif origColor == (0.5058823529411764, 0.4470588235294118, 0.7019607843137254):
      		line.set_color('black')
      		

def setFigLinesBW(fig):
    """
    Take each axes in the figure, and for each line in the axes, make the
    line viewable in black and white.
    """
    
    for ax in fig.get_axes():
        setAxLinesBW(ax)

stime.set()
stime.set_style('whitegrid')
plt.close('all')

envnum = argv[1]
maxruns = int(argv[2])
models = argv[3].split(' ')
headers = ['Planning Time [s]', 'Success [%]', 'Planner', '']

timelocation = 3
loglength = 4
timespermodel = []

timesOMPLrrt = []
timesOMPLbirrt = []
timesOMPLprm = []
omplrrtlogpath = os.path.join('logs/ompl/rrt/logs_env'+envnum+'.txt')
omplbirrtlogpath = os.path.join('logs/ompl/birrt/logs_env'+envnum+'.txt')
omplprmlogpath = os.path.join('logs/ompl/prm/logs_env'+envnum+'.txt')
successrates = []
datalists = []
maxtimes = []
timesteps = [i for i in xrange(61)]

with open(omplrrtlogpath) as omplrrtlog, open(omplbirrtlogpath) as omplbirrtlog, open(omplprmlogpath) as omplprmlog:
	for i,line in enumerate(omplrrtlog):
		loglocation = (i+1)%loglength
		if loglocation == timelocation:
			split = line.split(' ')
			try:
				if '.' in split[len(split) - 2]:
					time = float(split[len(split) - 2]) 
					timesOMPLrrt.append(time)
			except:
				pass

	for i,line in enumerate(omplbirrtlog):
		loglocation = (i+1)%loglength
		if loglocation == timelocation:
			split = line.split(' ')
			try:
				if '.' in split[len(split) - 2]:
					time = float(split[len(split) - 2]) 
					timesOMPLbirrt.append(time)
			except:
				pass

	if envnum == '9.2' or envnum == '10.2':
		loglength = 5
	for i,line in enumerate(omplprmlog):
		loglocation = (i+1)%loglength
		if loglocation == timelocation:
			split = line.split(' ')
			try:
				if '.' in split[len(split) - 2] and float(split[len(split) - 2]) < 60:
					time = float(split[len(split) - 2]) 
					timesOMPLprm.append(time)
			except:
				pass

if not timesOMPLrrt:
	timesOMPLrrt.append(0.0)
if not timesOMPLbirrt:
	timesOMPLbirrt.append(0.0)
if not timesOMPLprm:
	timesOMPLprm.append(0.0)

datalists.append(timesOMPLrrt)
datalists.append(timesOMPLbirrt)
datalists.append(timesOMPLprm)

aveD = np.average(timesOMPLrrt)
medD = np.median(timesOMPLrrt)
varD = np.var(timesOMPLrrt)
mxD = max(timesOMPLrrt)
mnD = min(timesOMPLrrt)
maxtimes.append(mxD)

print 'OMPL RRT - Planning Time statistics:'
print 'average: '+str(aveD)
print 'median: '+str(medD)
print 'variance: '+str(varD)
print 'max: '+str(mxD)
print 'min: '+str(mnD)
print ''

aveD = np.average(timesOMPLbirrt)
medD = np.median(timesOMPLbirrt)
varD = np.var(timesOMPLbirrt)
mxD = max(timesOMPLbirrt)
mnD = min(timesOMPLbirrt)
maxtimes.append(mxD)

print 'OMPL RRT-Connect - Planning Time statistics:'
print 'average: '+str(aveD)
print 'median: '+str(medD)
print 'variance: '+str(varD)
print 'max: '+str(mxD)
print 'min: '+str(mnD)
print ''

aveD = np.average(timesOMPLprm)
medD = np.median(timesOMPLprm)
varD = np.var(timesOMPLprm)
mxD = max(timesOMPLprm)
mnD = min(timesOMPLprm)
maxtimes.append(mxD)

print 'OMPL PRM - Planning Time statistics:'
print 'average: '+str(aveD)
print 'median: '+str(medD)
print 'variance: '+str(varD)
print 'max: '+str(mxD)
print 'min: '+str(mnD)
print ''


ratespermodel = []
for data in datalists:
	ratespertimestep = []
	for timestep in timesteps:
		success = 0
		for time in data:
			if time < timestep and time != 0.0:
				success += 1
		ratespertimestep.append((success/maxruns)*100)
	ratespermodel.append(ratespertimestep)


data = []
for i, rates in enumerate(ratespermodel):
	if i == 0:
		d = [[timestep, rates[timestep], 'RRT', 'RRT'] for timestep in timesteps]
		d = pd.DataFrame(d, columns=headers)
	elif i == 1:
		d = [[timestep, rates[timestep], 'RRT-Connect', 'RRT-Connect'] for timestep in timesteps]
		d = pd.DataFrame(d, columns=headers)
	else:
		d = [[timestep, rates[timestep], 'PRM', 'PRM'] for timestep in timesteps]
		d = pd.DataFrame(d, columns=headers)
	data.append(d)

timespermodel.append(pd.concat([data[0], data[1], data[2]]))
successrates.append((len(timesOMPLrrt)/maxruns)*100)
successrates.append((len(timesOMPLbirrt)/maxruns)*100)
successrates.append((len(timesOMPLprm)/maxruns)*100)

ratespermodel = []
for model in models:
	times = []
	logpath = os.path.join('logs/ll/'+model+'/logs_env'+envnum+'.txt') # maybe make seperate folder for each model
	
	if model == 'LL-RM' or model == 'LL-RM_rand':
		with open(logpath, 'r') as log:
			for i,line in enumerate(log):
				parts = line.split(',')
				try:
					if i%2 != 0 and len(parts) == 2:
						time = float(parts[0])
						times.append(time)
				except:
					pass
	else:
		with open(logpath, 'r') as log:
			for i,line in enumerate(log):
				parts = line.split(',')
				try:
					if len(parts) == 2:
						time = float(parts[0])
						times.append(time)
				except:
					pass

	if not times:
		times.append(0.0)

	datalists.append(times)

	# calculate descriptive statisitics and create plots
	ave = np.average(times)
	med = np.median(times)
	var = np.var(times)
	mx = max(times)
	mn = min(times)
	maxtimes.append(mx)

	print 'LL - '+model+' - Planning Time statistics:'
	print 'average: '+str(ave)
	print 'median: '+str(med)
	print 'variance: '+str(var)
	print 'max: '+str(mx)
	print 'min: '+str(mn)
	print ''

	ratespertimestep = []
	for timestep in timesteps:
		success = 0
		for time in times:
			if time < timestep and time != 0.0:
				success += 1
		ratespertimestep.append((success/maxruns)*100)
	ratespermodel.append(ratespertimestep)

	data = [[timestep, ratespertimestep[timestep], model, model] for timestep in timesteps]
	data = pd.DataFrame(data, columns=headers)

	timespermodel.append(data)
	successrates.append((len(times)/maxruns)*100)

totaldata = timespermodel[0]
for i, times in enumerate(timespermodel):
	if i > 0:
		totaldata = pd.concat([totaldata, times])

ax = stime.lineplot(x=headers[0], y=headers[1],data=totaldata, hue=headers[2])

ax.set_xlabel('Planning Time [s]')
ax.set_ylabel('Success [%]')
fig = ax.get_figure()
setFigLinesBW(fig)

#ax.get_legend().remove()
#ax.legend(framealpha=1.0, loc='upper center',bbox_to_anchor=(0.5,-0.05),fancybox=True, shadow=True, ncol=6)
#plt.show()
fig.savefig('results/'+'env'+envnum+'.png')#, bbox_inches='tight')
plt.close('all')


