import pdb, time
from sys import argv
import ompl.app as app
from ompl import base as ob
from ompl import geometric as og
from math import pi
from openravepy import *
from numpy import *
from functools import partial

envnum = argv[1]
numruns = int(argv[2])
planner = argv[3]
env = None
robot = None
jointLimits = []

def isStateValid(si, state):
	global env
	global robot
	valid = True
	if si.satisfiesBounds(state):
		values = []
		for i in xrange(3):
			if i == 0:
				for j in xrange(7):
					values.append(state[i][j])
			elif i == 1:
				for j in xrange(2):
					values.append(state[i][j])
			else:
				values.append(state[i].value)

		with env:
			robot.SetActiveDOFValues(values)
			if env.CheckCollision(robot):
				valid = False
	else:
		valid = False

	return valid

def isStateValid2(si, state):
	global env
	global robot
	valid = True
	if si.satisfiesBounds(state):
		values = []
		for i in xrange(2):
			if i == 0:
				for j in xrange(2):
					values.append(state[i][j])
			else:
				values.append(state[i].value)

		with env:
			robot.SetActiveDOFValues(values)
			if env.CheckCollision(robot):
				valid = False
	else:
		valid = False

	return valid

def plan7DOF_SE2(s,g,plannertype):
	global jointLimits
	# construct compound state space
	statespace = ob.CompoundStateSpace()

	# 7DOF Arm
	jointspace = ob.RealVectorStateSpace(7)
	jointbounds = ob.RealVectorBounds(7)
	for i, jlimit in enumerate(jointLimits[0]):
		jointbounds.setLow(i, jlimit)
		jointbounds.setHigh(i, jointLimits[1][i])
	jointspace.setBounds(jointbounds)
	statespace.addSubspace(jointspace, 1.0)

	# R2
	r2space = ob.RealVectorStateSpace(2)
	r2bounds = ob.RealVectorBounds(2)
	if envnum == '10.2':
		r2bounds.setLow(-4)
		r2bounds.setHigh(4)
	else:
		r2bounds.setLow(-2.5)
		r2bounds.setHigh(2.5)
	r2space.setBounds(r2bounds)
	statespace.addSubspace(r2space, 1.0)

	# SO2
	so2space = ob.SO2StateSpace()
	statespace.addSubspace(so2space, 1.0)

	# set up motion plan
	ss = og.SimpleSetup(statespace)
	si = ss.getSpaceInformation()
	ss.setStateValidityChecker(ob.StateValidityCheckerFn(partial(isStateValid, si)))
	
	# load start and goal
	start = ob.State(statespace)
	for i, val in enumerate(s):
		start[i] = val
	goal = ob.State(statespace)
	for i, val in enumerate(g):
		goal[i] = val
	ss.setStartAndGoalStates(start, goal)

	# set up planner
	if plannertype == 'birrt':
		planner = og.RRTConnect(si)
		planner.setRange(0.5)
	elif plannertype == 'rrt':
		planner = og.RRT(si)
		planner.setRange(0.5)
	elif plannertype == 'prm':
		planner = og.PRM(si)

	ss.setPlanner(planner)
	ss.setup()

	if plannertype == 'prm':
		planner.growRoadmap(1)

	# execute planner
	solved = ss.solve(60)
	if solved and ss.haveExactSolutionPath():
		print 'Length: ' + str(ss.getSolutionPath().length())
		if plannertype == 'prm':
			print ''
		#print("Found solution:\n%s" % ss.getSolutionPath())
		return True 
	else:
		return False

def planSE2(s,g,plannertype):
	# construct compound state space
	statespace = ob.CompoundStateSpace()

	# R2
	r2space = ob.RealVectorStateSpace(2)
	r2bounds = ob.RealVectorBounds(2)
	if envnum == '9.1' or envnum == '11.0':
		r2bounds.setLow(-10)
		r2bounds.setHigh(10)
	else:
		r2bounds.setLow(-2.5)
		r2bounds.setHigh(2.5)
	r2space.setBounds(r2bounds)
	statespace.addSubspace(r2space, 1.0)

	# SO2
	so2space = ob.SO2StateSpace()
	statespace.addSubspace(so2space, 1.0)

	# set up motion plan
	ss = og.SimpleSetup(statespace)
	si = ss.getSpaceInformation()
	ss.setStateValidityChecker(ob.StateValidityCheckerFn(partial(isStateValid2, si)))
	
	# load start and goal
	start = ob.State(statespace)
	for i, val in enumerate(s):
		start[i] = val
	goal = ob.State(statespace)
	for i, val in enumerate(g):
		goal[i] = val
	ss.setStartAndGoalStates(start, goal)

	# set up planner
	if plannertype == 'birrt':
		planner = og.RRTConnect(si)
		planner.setRange(0.2)
	elif plannertype == 'rrt':
		planner = og.RRT(si)
		planner.setRange(0.2)
	elif plannertype == 'prm':
		planner = og.PRM(si)
	
	ss.setPlanner(planner)
	ss.setup()

	if plannertype == 'prm':
		planner.growRoadmap(1)

	# execute planner
	solved = ss.solve(60)
	if solved and ss.haveExactSolutionPath():
		print 'Length: ' + str(ss.getSolutionPath().length())
		#print("Found solution:\n%s" % ss.getSolutionPath())
		return True 
	else:
		return False


'''
run plan
'''
def main():
	global env
	global robot
	global jointLimits
	env = Environment()
	env.Load('envs/'+envnum+'.xml')
	collisionChecker = RaveCreateCollisionChecker(env, 'fcl_')
	env.SetCollisionChecker(collisionChecker)
	robot = env.GetRobots()[0]
	try:
		robot.SetActiveDOFs(robot.GetActiveManipulator().GetArmIndices(),DOFAffine.X|DOFAffine.Y|DOFAffine.RotationAxis,[0,0,1]) # set arm joints
		robot.Grab(env.GetKinBody('mug6'))
	except:
		robot.SetActiveDOFs([],DOFAffine.X|DOFAffine.Y|DOFAffine.RotationAxis,[0,0,1]) # set arm joints
	jointLimits = list(robot.GetActiveDOFLimits())
	jointLimits[0] = jointLimits[0][0:len(jointLimits[0])-3]
	jointLimits[1] = jointLimits[1][0:len(jointLimits[1])-3]
	env.UpdatePublishedBodies()
	time.sleep(0.1)

	if envnum == '9.0':
	    start = [1.5,-1.5,0]
	    goal = [-1.5,-1.0,0]
	elif envnum == '9.1':
	    start = [-7,-7,0] 
	    goal = [-9,7,0]
	elif envnum == '9.2':
		start = [0.0205585116,0.593383701,-0.114082917,2.03588441,0,0.518159381,3]+[-0.8,0.14,0]
		goal = [0.0205585116,0.593383701,-0.114082917,2.03588441,0,0.518159381,3]+[-1.76,-1.73,0]
	elif envnum == '10.2':
		start = [0.0205585116,0.593383701,-0.114082917,2.03588441,0,0.518159381,3]+[-1.19361,-1.65621,0]
		goal = [0.0205585116,0.593383701,-0.114082917,2.03588441,0,0.518159381,3]+[1.59429526,-0.857801855,-1.56981169]
	elif envnum == '11.0':
		start = [2.5,-9.25,0]
		goal = [1.25,9.5,0]
	else:
	    start = [1.5,-1.5,0]
	    goal = [-1.5,-1.5,0]

	for i in xrange(numruns):
		if envnum == '9.2' or envnum == '10.2':
			success = plan7DOF_SE2(start,goal,planner)
		else:
			success = planSE2(start,goal,planner)
	
	RaveDestroy()

if __name__ == "__main__":
    main()